-- Uni-Mates Chess Academy Training Portal Database Schema
-- Designed for Supabase/PostgreSQL

create extension if not exists "uuid-ossp";

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text unique not null,
  role text not null check (role in ('student', 'coach', 'parent', 'admin')) default 'student',
  created_at timestamptz default now()
);

create table public.students (
  id uuid primary key default uuid_generate_v4(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  parent_id uuid references public.profiles(id) on delete set null,
  coach_id uuid references public.profiles(id) on delete set null,
  age int,
  rating int default 0,
  school text,
  level text check (level in ('beginner','intermediate','advanced')) default 'beginner',
  active boolean default true,
  created_at timestamptz default now()
);

create table public.courses (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text unique not null,
  description text,
  category text,
  level text check (level in ('beginner','intermediate','advanced','all')) default 'all',
  cover_image_url text,
  created_by uuid references public.profiles(id),
  is_published boolean default false,
  created_at timestamptz default now()
);

create table public.lessons (
  id uuid primary key default uuid_generate_v4(),
  course_id uuid not null references public.courses(id) on delete cascade,
  title text not null,
  content text,
  video_url text,
  pgn text,
  order_number int not null default 1,
  lesson_type text check (lesson_type in ('text','video','pgn','quiz','mixed')) default 'mixed',
  created_at timestamptz default now()
);

create table public.course_enrollments (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.students(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  enrolled_at timestamptz default now(),
  unique(student_id, course_id)
);

create table public.lesson_progress (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.students(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed boolean default false,
  completed_at timestamptz,
  unique(student_id, lesson_id)
);

create table public.puzzles (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  fen text not null,
  solution_san text[] not null,
  theme text not null,
  difficulty int check (difficulty between 1 and 10) default 1,
  rating_level int default 800,
  explanation text,
  created_by uuid references public.profiles(id),
  is_published boolean default false,
  created_at timestamptz default now()
);

create table public.lesson_puzzles (
  id uuid primary key default uuid_generate_v4(),
  lesson_id uuid references public.lessons(id) on delete cascade,
  puzzle_id uuid references public.puzzles(id) on delete cascade,
  order_number int default 1,
  unique(lesson_id, puzzle_id)
);

create table public.puzzle_attempts (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid not null references public.students(id) on delete cascade,
  puzzle_id uuid not null references public.puzzles(id) on delete cascade,
  moves_played text[],
  is_correct boolean default false,
  hints_used int default 0,
  attempt_time_seconds int,
  created_at timestamptz default now()
);

create table public.homework (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  description text not null,
  course_id uuid references public.courses(id) on delete set null,
  lesson_id uuid references public.lessons(id) on delete set null,
  assigned_by uuid references public.profiles(id) on delete set null,
  due_date date,
  created_at timestamptz default now()
);

create table public.homework_assignments (
  id uuid primary key default uuid_generate_v4(),
  homework_id uuid references public.homework(id) on delete cascade,
  student_id uuid references public.students(id) on delete cascade,
  assigned_at timestamptz default now(),
  unique(homework_id, student_id)
);

create table public.homework_submissions (
  id uuid primary key default uuid_generate_v4(),
  homework_id uuid references public.homework(id) on delete cascade,
  student_id uuid references public.students(id) on delete cascade,
  answer text,
  file_url text,
  coach_feedback text,
  score int check (score between 0 and 100),
  submitted_at timestamptz default now()
);

create table public.payments (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid references public.students(id) on delete cascade,
  amount numeric(10,2) not null,
  package text check (package in ('basic','standard','premium')),
  status text check (status in ('pending','paid','failed','cancelled')) default 'pending',
  payment_provider text,
  provider_reference text,
  paid_at timestamptz,
  created_at timestamptz default now()
);

create table public.certificates (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid references public.students(id) on delete cascade,
  course_id uuid references public.courses(id) on delete cascade,
  certificate_url text,
  issued_at timestamptz default now()
);

-- Enable RLS
alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.courses enable row level security;
alter table public.lessons enable row level security;
alter table public.course_enrollments enable row level security;
alter table public.lesson_progress enable row level security;
alter table public.puzzles enable row level security;
alter table public.lesson_puzzles enable row level security;
alter table public.puzzle_attempts enable row level security;
alter table public.homework enable row level security;
alter table public.homework_assignments enable row level security;
alter table public.homework_submissions enable row level security;
alter table public.payments enable row level security;
alter table public.certificates enable row level security;

