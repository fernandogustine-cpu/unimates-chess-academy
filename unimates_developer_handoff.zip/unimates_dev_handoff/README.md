# Uni-Mates Chess Academy Training Portal

Developer-ready handoff package for building a ChessFactor-style training website for Uni-Mates Chess Academy by Coach Fernando.

## Recommended Stack

- Frontend: Next.js App Router
- Backend/DB/Auth: Supabase
- Chessboard: Chessground
- Move validation: chess.js
- Hosting: Vercel
- Payments: PayFast or Yoco
- AI Lessons: OpenAI API or similar AI model

## Core Modules

1. Public marketing website
2. Student accounts
3. Coach/admin dashboard
4. Course and lesson system
5. Puzzle trainer
6. Homework submissions
7. Student progress reports
8. Payments and subscriptions
9. AI-powered lesson generator

## Suggested Build Order

1. Authentication and roles
2. Student dashboard
3. Coach dashboard
4. Course builder
5. Lesson viewer
6. Puzzle trainer
7. Homework system
8. Payments
9. AI lesson generator
10. Certificates and reports

