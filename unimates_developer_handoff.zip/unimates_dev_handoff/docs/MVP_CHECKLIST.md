# MVP Checklist

Launch when these are complete:

- [ ] Homepage
- [ ] Login/register
- [ ] Student dashboard
- [ ] Coach dashboard
- [ ] Create course
- [ ] Add lesson
- [ ] Add puzzle from FEN
- [ ] Student can solve puzzle
- [ ] Puzzle attempt saved
- [ ] Homework assigned
- [ ] Homework submitted
- [ ] Coach feedback added
- [ ] Pricing page
- [ ] Payment instructions or gateway
- [ ] First 5 courses uploaded
- [ ] First 50 puzzles uploaded
