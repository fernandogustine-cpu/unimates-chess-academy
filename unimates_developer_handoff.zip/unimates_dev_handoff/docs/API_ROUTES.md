# API Routes / Server Actions

## Auth
- POST /auth/signup
- POST /auth/login
- POST /auth/logout

## Courses
- GET /courses
- POST /coach/courses
- PATCH /coach/courses/:id
- DELETE /coach/courses/:id

## Lessons
- GET /courses/:courseId/lessons
- POST /coach/lessons
- PATCH /coach/lessons/:id
- POST /student/lessons/:id/complete

## Puzzles
- GET /puzzles?theme=&difficulty=&rating=
- POST /coach/puzzles
- PATCH /coach/puzzles/:id
- POST /student/puzzle-attempts

## Homework
- GET /student/homework
- POST /coach/homework
- POST /coach/homework/:id/assign
- POST /student/homework/:id/submit
- PATCH /coach/submissions/:id/feedback

## Reports
- GET /coach/students/:id/report
- GET /student/report

## Payments
- POST /payments/create-checkout
- POST /payments/webhook

## AI Lessons
- POST /coach/ai/generate-lesson
- POST /coach/ai/generate-parent-report
