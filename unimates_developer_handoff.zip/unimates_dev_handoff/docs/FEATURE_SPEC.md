# Feature Specification

## Public Website
Purpose: market the academy and direct users to register or pay.
Pages: Home, About, Courses, Pricing, Contact, Login.

## Student Account
Students must be able to view assigned courses, continue lessons, solve puzzles, submit homework, and see Coach Fernando feedback.

## Coach Dashboard
Coach can create training material, manage students, assign work, and track progress.

## Puzzle Trainer
A tactical trainer similar to ChessFactor/Chessable style.
Required:
- Chessboard
- FEN position
- Solution sequence
- Correct/wrong feedback
- Reset button
- Hint button
- Save attempts
- Accuracy and streaks

## AI Lesson System
AI is used only as a draft assistant. Coach Fernando approves content before publishing.

## Parent View
Parents can see:
- Lessons completed
- Homework submitted
- Puzzle accuracy
- Coach notes
- Payment status
