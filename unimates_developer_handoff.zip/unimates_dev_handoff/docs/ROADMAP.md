# Development Roadmap

## Phase 1: Foundation
- Create Next.js app with App Router.
- Connect Supabase project.
- Add auth: email/password login.
- Create profile record after signup.
- Add role-based redirects: student, coach, parent, admin.

## Phase 2: Dashboards

### Student Dashboard
- Continue current course.
- Daily puzzle.
- Homework due.
- Progress percentage.
- Coach feedback.

### Coach Dashboard
- Student list.
- Create course.
- Create lesson.
- Add puzzle.
- Assign homework.
- View reports.

## Phase 3: Courses
- Course listing page.
- Course detail page.
- Lesson viewer.
- Mark lesson complete.
- Embed YouTube videos.
- Add PGN text viewer initially.

## Phase 4: Puzzle Trainer
- Use Chessground for board UI.
- Use chess.js for legal moves.
- Load FEN from puzzles table.
- Validate SAN move against solution_san array.
- Auto-play opponent reply.
- Save attempts.
- Track accuracy by theme.

## Phase 5: Homework
- Coach creates homework.
- Coach assigns to one or multiple students.
- Student submits answer/file.
- Coach adds score and feedback.

## Phase 6: Payments
- Pricing page: R100, R250, R500.
- Integrate PayFast/Yoco.
- Save payment status.
- Lock premium courses behind active payment.

## Phase 7: AI Lesson Generator
- Coach inputs topic, age, rating, level, lesson length.
- AI returns lesson, exercises, homework, puzzle ideas, parent summary.
- Coach reviews before publishing.

## Phase 8: Reports and Certificates
- Monthly progress report.
- Accuracy by theme.
- Completed courses.
- Generate certificate PDF.
