import { Chess } from 'chess.js';

export type Puzzle = {
  id: string;
  fen: string;
  solution_san: string[];
};

export type PuzzleState = {
  chess: Chess;
  moveIndex: number;
  completed: boolean;
  mistakes: number;
  playedMoves: string[];
};

export function createPuzzleState(puzzle: Puzzle): PuzzleState {
  return {
    chess: new Chess(puzzle.fen),
    moveIndex: 0,
    completed: false,
    mistakes: 0,
    playedMoves: [],
  };
}

export function attemptMove(state: PuzzleState, puzzle: Puzzle, move: { from: string; to: string; promotion?: string }) {
  const expectedSan = puzzle.solution_san[state.moveIndex];
  const testChess = new Chess(state.chess.fen());
  const result = testChess.move(move);

  if (!result) {
    return { ...state, mistakes: state.mistakes + 1, feedback: 'Illegal move' };
  }

  if (result.san !== expectedSan) {
    return { ...state, mistakes: state.mistakes + 1, feedback: 'Try again' };
  }

  state.chess.move(move);
  state.playedMoves.push(result.san);
  state.moveIndex += 1;

  // Auto-play opponent reply if included in solution sequence
  if (state.moveIndex < puzzle.solution_san.length) {
    const opponentSan = puzzle.solution_san[state.moveIndex];
    const opponentMove = state.chess.move(opponentSan);
    if (opponentMove) {
      state.playedMoves.push(opponentMove.san);
      state.moveIndex += 1;
    }
  }

  state.completed = state.moveIndex >= puzzle.solution_san.length;

  return {
    ...state,
    feedback: state.completed ? 'Puzzle solved!' : 'Good move! Continue.',
  };
}
